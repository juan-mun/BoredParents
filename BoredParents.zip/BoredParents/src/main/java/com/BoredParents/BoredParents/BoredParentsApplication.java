package com.BoredParents.BoredParents;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoredParentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoredParentsApplication.class, args);
	}

}
