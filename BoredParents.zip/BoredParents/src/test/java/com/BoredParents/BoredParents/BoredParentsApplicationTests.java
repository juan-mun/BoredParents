package com.BoredParents.BoredParents;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoredParentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
